
$(function(){
    $(".ok_btn").click(function(){
        $(this).parents('#layer_contanier').hide();
    });
});